// Helper.js
export const BASE_URL = "https://pos.idotsolution.com/api";
