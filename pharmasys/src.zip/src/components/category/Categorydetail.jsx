import React, { useCallback, useMemo, useRef, useState, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import "../common/style.css";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { ExcelExportModule } from "ag-grid-enterprise";
import { ModuleRegistry } from 'ag-grid-community';
import GlobalModal from "../customhooks/GlobalModal";
import CustomSelect from "../customhooks/CustomSelect";
import { RowGroupingModule, PivotModule, TreeDataModule, ServerSideRowModelModule, SetFilterModule } from 'ag-grid-enterprise';
import { AllCommunityModule } from "ag-grid-community";
import { Modal, Form, Spin, message, Button, Empty } from "antd";
import useScreenSize from '../common/useScreenSize';
import { useTableHeader } from '../common/useTableHeader';
import ActionCellRenderer from '../common/ActionCellRenderer';
import { CategoriesDetails } from "../../components/APi/CategoryApi";


ModuleRegistry.registerModules([
  AllCommunityModule, 
  ExcelExportModule,
  RowGroupingModule,
  PivotModule,
  TreeDataModule,
  ServerSideRowModelModule,
  SetFilterModule
]);

const Categorydetail = () => {
  const [rowData, setRowData] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [messageApi, contextHolder] = message.useMessage();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const gridRef = useRef(null);
  const screenSize = useScreenSize(gridRef);
  const loadingRef = useRef(false); 
  

  const fetchInvoiceData = useCallback(async () => {
    if (loadingRef.current) return;
    
    loadingRef.current = true;
 
    
    try {
       // messageApi.loading({ content: 'Loading category data...', key: 'loadingData', duration: 0 });
      
      // await new Promise(resolve => setTimeout(resolve, 800));
      
      const response = await CategoriesDetails();
      const data = response?.data?.data || [];
      setRowData(data);
      setFilteredData(data);
      
       if (data.length > 0) {
        messageApi.success({ content: 'Data loaded successfully', key: 'loadingData' });
      } else {
        messageApi.info({ content: 'No category data available', key: 'loadingData' });
      }
    } catch (err) {
      setError(err.message || 'Failed to fetch data');
      messageApi.error({ content: `Failed to fetch data: ${err.message || 'Unknown error'}`, key: 'loadingData' });
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
      // loadingRef.current = false;
    }
  }, [messageApi]);

  // Define all handlers before they're used
  const handleRefreshData = useCallback(() => {
    // Only trigger refresh if not already loading
    if (!loadingRef.current) {
      fetchInvoiceData();
    } else {
      messageApi.info('Data is currently loading');
    }
  }, [fetchInvoiceData, messageApi]);

  const handleExportPDF = useCallback(() => {
    const fileName = prompt("Enter file name for PDF:", "category-data");
    if (!fileName) return;
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Category Report', 14, 22);
    doc.setFontSize(11);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 30);
    const visibleCols = columnDefs.filter(col => !col.hide && col.field !== 'actions');
    const columns = visibleCols.map((col) => col.headerName || col.field);
    const rows = rowData.map((row) =>
      visibleCols.map((col) => row[col.field] || "")
    );

    doc.autoTable({
      head: [columns],
      body: rows,
      startY: 40,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [66, 139, 202] }
    });
    doc.save(`${fileName}.pdf`);
  }, [rowData]);

  const handleExportExcel = useCallback(() => {
    if (gridRef.current && gridRef.current.api) {
      gridRef.current.api.exportDataAsExcel({
        fileName: 'category-data.xlsx',
        sheetName: 'Categories'
      });
    }
  }, []);

  const setAutoHeight = useCallback(() => {
    if (gridRef.current && gridRef.current.api) {
      gridRef.current.api.setGridOption("domLayout", "autoHeight");
      const gridElement = document.querySelector("#myGrid");
      if (gridElement) {
        gridElement.style.height = "";
      }
    }
  }, []);

  const setFixedHeight = useCallback(() => {
    if (gridRef.current && gridRef.current.api) {
      gridRef.current.api.setGridOption("domLayout", "normal");
      const gridElement = document.querySelector("#myGrid");
      if (gridElement) {
        gridElement.style.height = "500px";
      }
    }
  }, []);

  const handleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  }, []);

  const handleTableSizeChange = useCallback(({ key }) => {
    messageApi.info(`Table layout set to: ${key}`);
    switch(key) {
      case "Auto Height": setAutoHeight(); break;
      case "Fixed Height": setFixedHeight(); break;
      case "Fullscreen": handleFullscreen(); break;
      default: break;
    }
  }, [messageApi, setAutoHeight, setFixedHeight, handleFullscreen]);

  const AddnewModal = useCallback((record) => {
    setEditingRecord(record ? { ...record } : { categoryId: '', category: '' });
    setIsModalVisible(true);
  }, []);

  // Action handlers
  const handleEdit = useCallback((data) => {
    AddnewModal(data);
  }, [AddnewModal]);

  const handleDelete = useCallback((data) => {
    console.log("Delete category:", data);
    // Add your delete API call here
    messageApi.success('Category deleted successfully');
  }, [messageApi]);

  // Now we can safely use all the handlers in useTableHeader
  const { renderMobileHeader, renderDesktopHeader } = useTableHeader({
    title: "Category Management 123",
    onRefresh: handleRefreshData,
    onExportExcel: handleExportExcel,
    onExportPDF: handleExportPDF,
    onAddNew: () => AddnewModal(null),
    onTableSizeChange: handleTableSizeChange,
    onSearchChange: (e) => setSearchText(e.target.value),
    searchText,
    rowData,
    screenSize
  });

  // Get column definitions
  const getColumnDefs = useCallback(() => {
    return [
      {
        headerName: "Category ID",
        field: "categoryId",
        sortable: true,
        filter: true,
        minWidth: 140,
        hide: screenSize === 'xs',
      },
      {
        headerName: "Category Name",
        field: "category",
        sortable: true,
        filter: true,
        minWidth: 140,
      },
      {
        headerName: "Actions",
        field: "actions",
        sortable: false,
        filter: false,
        minWidth: 110,
        cellRenderer: (params) => (
          <ActionCellRenderer 
            data={params.data}
            onEdit={handleEdit}
            onDelete={handleDelete}
            isUpdate={false} 
            editTooltip="Edit category"
            deleteTooltip="Delete category"
            deleteConfirmText="Are you sure you want to delete this category?"
          />
        ),
        suppressSizeToFit: true,
      }
    ];
  }, [screenSize, handleEdit, handleDelete]);
  
  const columnDefs = useMemo(() => getColumnDefs(), [getColumnDefs]);
  
  const defaultColDef = useMemo(() => ({
    enableRowGroup: true,
    enableValue: true,
    filter: true,
    resizable: true,
    suppressSizeToFit: false
  }), []);

  const popupParent = useMemo(() => document.body, []);
  
  // Effect hooks - Only run once on mount with proper cleanup
  useEffect(() => {
    // Set loading to true immediately to show loading state
    setLoading(true);
    fetchInvoiceData();
    // Use a timeout to prevent component from unmounting before fetch completes
    // const timeoutId = setTimeout(() => {
      
    // }, 0);
    
    return () => {
    //  clearTimeout(timeoutId);
      // Reset state on unmount
      loadingRef.current = false;
    };
  }, [fetchInvoiceData]);

  // Optimize filtering for better performance
  useEffect(() => {
    const filterData = () => {
      if (!searchText.trim()) {
        setFilteredData(rowData);
        return;
      }
      
      const searchLower = searchText.toLowerCase();
      const filtered = rowData.filter(row =>
        (row.categoryId && row.categoryId.toString().toLowerCase().includes(searchLower)) ||
        (row.category && row.category.toLowerCase().includes(searchLower))
      );
  
      setFilteredData(filtered);
    };
    
    // Debounce search for better performance
    const handler = setTimeout(() => {
      filterData();
      
      // Update grid filters if grid is ready
      if (gridRef.current && gridRef.current.api) {
        gridRef.current.api.onFilterChanged();
      }
    }, 300);
    
    return () => clearTimeout(handler);
  }, [searchText, rowData]);

  const modalFields = [
    {
      name: 'category',
      label: 'Category Name',
      type: 'input',
      rules: [{ required: true, message: 'Category name is required' }],
    },
    {
      name: 'customSelectCategory',
      label: 'Project Selection',
      component: <CustomSelect />,
    }
  ];
  
  // Split loading indicator into its own component for cleaner JSX
  const renderLoadingState = () => (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column',
      justifyContent: 'center', 
      alignItems: 'center', 
      padding: '80px 0',
      minHeight: '400px',
      background: '#f9f9f9',
      borderRadius: '8px'
    }}>
      <Spin size="large" />
      {/* <div style={{ marginTop: '20px', color: '#666' }}>
        <h3 style={{ fontWeight: 'normal' }}>Loading category data...</h3>
        <p>Please wait while we retrieve the category information.</p>
      </div> */}
    </div>
  );

  // Split error state into its own component
  const renderErrorState = () => (
    <div style={{ 
      padding: '40px 20px', 
      textAlign: 'center', 
      background: '#fff1f0',
      border: '1px solid #ffccc7',
      borderRadius: '8px' 
    }}>
      <h3 style={{ color: '#cf1322', marginBottom: '15px' }}>Error Loading Data</h3>
      <p style={{ color: '#555', marginBottom: '20px' }}>{error}</p>
      <Button type="primary" onClick={handleRefreshData}>Try Again</Button>
    </div>
  );

  // Empty state component
  const renderEmptyState = () => (
    <Empty
      image={Empty.PRESENTED_IMAGE_SIMPLE}
      description={
        <span>
          No categories found matching your search criteria
        </span>
      }
    >
      {/* <Button type="primary" onClick={() => AddnewModal(null)}>Add Category</Button> */}
    </Empty>
  );
  
  return (
    <div className="category-management-container" style={{ padding: '10px', maxWidth: '100%' }}>
      {contextHolder}
      {/* Render appropriate header based on screen size */}
      {screenSize === 'xs' || screenSize === 'sm' ? renderMobileHeader() : renderDesktopHeader()}
      
      {loading ? renderLoadingState() : error ? renderErrorState() : (
        <div 
          id="myGrid" 
          className="ag-theme-alpine" 
          style={{
            height: screenSize === 'xs' ? '450px' : '500px', 
            width: '100%',
            fontSize: screenSize === 'xs' ? '12px' : '14px'
          }}
        >
          {filteredData.length === 0 ? renderEmptyState() : (
            <AgGridReact
              gridOptions={{ suppressMenuHide: true }}
              columnDefs={columnDefs}
              ref={gridRef}
              rowData={filteredData}
              defaultColDef={defaultColDef}
              pagination={true}
              popupParent={popupParent}
              paginationPageSize={screenSize === 'xs' ? 5 : 10}
              paginationPageSizeSelector={[5, 10, 20, 50, 100]}
              domLayout='normal'
              suppressCellFocus={true}
              animateRows={true}
              enableCellTextSelection={true}
              onGridReady={params => {
                params.api.sizeColumnsToFit();
                if (screenSize === 'xs') {
                  params.api.setGridOption('rowHeight', 40);
                }
              }}
              onFirstDataRendered={params => params.api.sizeColumnsToFit()}
              // overlayNoRowsTemplate="<span style='padding: 20px; display: inline-block;'>No categories found matching your search criteria</span>"
            />
          )}
        </div>
      )}
      
      <GlobalModal
        visible={isModalVisible}
        title={editingRecord?.categoryId ? 'Edit Category' : 'Add New Category'}
        onCancel={() => setIsModalVisible(false)}
        initialValues={editingRecord}
        fields={modalFields}
        width={800}
      />
    </div>
  );
};

export default Categorydetail;